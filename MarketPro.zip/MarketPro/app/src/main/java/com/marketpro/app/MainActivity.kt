package com.marketpro.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.platform.LocalContext
import androidx.room.Room
import com.marketpro.app.data.*
import kotlinx.coroutines.launch
import java.text.NumberFormat
import java.util.Locale

private val Ink = Color(0xFF17243A)
private val Green = Color(0xFF0E9F6E)
private val Canvas = Color(0xFFF4F7F8)
private val Muted = Color(0xFF718096)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MarketProApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MarketProApp() {
    val context = LocalContext.current
    val db = remember { MarketDatabase.get(context) }
    val products by db.productDao().observeAll().collectAsState(initial = emptyList())
    val productCount by db.productDao().count().collectAsState(initial = 0)
    val scope = rememberCoroutineScope()
    var selected by remember { mutableStateOf("الرئيسية") }
    var showAdd by remember { mutableStateOf(false) }

    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = Green, secondary = Ink, background = Canvas,
            surface = Color.White, onPrimary = Color.White
        )
    ) {
        CompositionLocalProvider(androidx.compose.ui.platform.LocalLayoutDirection provides androidx.compose.ui.unit.LayoutDirection.Rtl) {
            Scaffold(
                containerColor = Canvas,
                topBar = {
                    TopAppBar(
                        title = {
                            Column {
                                Text("Market Pro", fontWeight = FontWeight.ExtraBold, color = Ink, fontSize = 20.sp)
                                Text("إدارة محلك بكل سهولة", color = Muted, fontSize = 11.sp)
                            }
                        },
                        actions = {
                            Surface(shape = RoundedCornerShape(50), color = Color(0xFFE5F6EF), modifier = Modifier.padding(end = 14.dp)) {
                                Row(Modifier.padding(horizontal = 10.dp, vertical = 7.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.CloudOff, null, tint = Green, modifier = Modifier.size(15.dp))
                                    Spacer(Modifier.width(5.dp))
                                    Text("يعمل دون إنترنت", color = Green, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                                }
                            }
                        },
                        colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.White)
                    )
                },
                bottomBar = {
                    NavigationBar(containerColor = Color.White) {
                        val items = listOf("الرئيسية", "المنتجات", "المبيعات", "المزيد")
                        val icons = listOf(Icons.Default.Home, Icons.Default.Inventory2, Icons.Default.PointOfSale, Icons.Default.Menu)
                        items.forEachIndexed { index, label ->
                            NavigationBarItem(
                                selected = selected == label,
                                onClick = { selected = label },
                                icon = { Icon(icons[index], contentDescription = label) },
                                label = { Text(label, fontSize = 10.sp) }
                            )
                        }
                    }
                },
                floatingActionButton = {
                    if (selected == "المنتجات") {
                        FloatingActionButton(onClick = { showAdd = true }, containerColor = Green, contentColor = Color.White) {
                            Icon(Icons.Default.Add, contentDescription = "إضافة منتج")
                        }
                    }
                }
            ) { padding ->
                when (selected) {
                    "الرئيسية" -> Dashboard(Modifier.padding(padding), productCount)
                    "المنتجات" -> ProductsScreen(Modifier.padding(padding), products, onDelete = { id -> scope.launch { db.productDao().deleteById(id) } })
                    "المبيعات" -> PlaceholderScreen(Modifier.padding(padding), "نقطة البيع", "سيتم بناء شاشة البيع والفواتير في المرحلة التالية")
                    else -> PlaceholderScreen(Modifier.padding(padding), "المزيد", "العملاء • الموردون • المصروفات • التقارير • الإعدادات")
                }
            }
        }

        if (showAdd) {
            AddProductDialog(
                onDismiss = { showAdd = false },
                onSave = { name, barcode, price, qty ->
                    scope.launch {
                        db.productDao().insert(Product(
                            name = name.trim(), barcode = barcode.trim(),
                            priceAgorot = (price.toDoubleOrNull()?.times(100))?.toLong() ?: 0L,
                            quantity = qty.toDoubleOrNull() ?: 0.0
                        ))
                        showAdd = false
                    }
                }
            )
        }
    }
}

@Composable
fun Dashboard(modifier: Modifier, count: Int) {
    LazyColumn(modifier.fillMaxSize().padding(horizontal = 16.dp), contentPadding = PaddingValues(top = 18.dp, bottom = 24.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item {
            Text("أهلاً بك 👋", fontSize = 23.sp, fontWeight = FontWeight.Bold, color = Ink)
            Text("إليك نظرة سريعة على متجرك اليوم", color = Muted, fontSize = 13.sp)
        }
        item {
            Surface(shape = RoundedCornerShape(22.dp), color = Ink, modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(20.dp)) {
                    Text("إجمالي المبيعات اليوم", color = Color(0xFFCFD8E3), fontSize = 13.sp)
                    Spacer(Modifier.height(8.dp))
                    Text("₪ 0.00", color = Color.White, fontSize = 32.sp, fontWeight = FontWeight.ExtraBold)
                    Spacer(Modifier.height(12.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.TrendingUp, null, tint = Color(0xFF66D6A8), modifier = Modifier.size(17.dp))
                        Spacer(Modifier.width(5.dp))
                        Text("ستظهر إحصائيات مبيعاتك هنا", color = Color(0xFFCFD8E3), fontSize = 11.sp)
                    }
                }
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                StatCard("المنتجات", count.toString(), Icons.Default.Inventory2, Modifier.weight(1f))
                StatCard("الفواتير", "0", Icons.Default.ReceiptLong, Modifier.weight(1f))
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                StatCard("الأرباح", "₪ 0", Icons.Default.AccountBalanceWallet, Modifier.weight(1f))
                StatCard("الديون", "₪ 0", Icons.Default.CreditCard, Modifier.weight(1f))
            }
        }
        item {
            Surface(color = Color.White, shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Bolt, null, tint = Green)
                        Spacer(Modifier.width(8.dp))
                        Text("إجراءات سريعة", fontWeight = FontWeight.Bold, color = Ink)
                    }
                    Spacer(Modifier.height(12.dp))
                    Text("ابدأ بإضافة منتجات متجرك من قسم المنتجات. بياناتك تُحفظ محلياً على الجهاز.", color = Muted, fontSize = 12.sp, lineHeight = 19.sp)
                }
            }
        }
    }
}

@Composable
fun StatCard(title: String, value: String, icon: androidx.compose.ui.graphics.vector.ImageVector, modifier: Modifier = Modifier) {
    Surface(modifier, color = Color.White, shape = RoundedCornerShape(18.dp)) {
        Column(Modifier.padding(15.dp)) {
            Icon(icon, null, tint = Green, modifier = Modifier.size(21.dp))
            Spacer(Modifier.height(12.dp))
            Text(value, color = Ink, fontWeight = FontWeight.Bold, fontSize = 20.sp)
            Text(title, color = Muted, fontSize = 11.sp)
        }
    }
}

@Composable
fun ProductsScreen(modifier: Modifier, products: List<Product>, onDelete: (Long) -> Unit) {
    Column(modifier.fillMaxSize().padding(horizontal = 16.dp)) {
        Spacer(Modifier.height(18.dp))
        Text("المنتجات", color = Ink, fontSize = 23.sp, fontWeight = FontWeight.Bold)
        Text("إدارة الأصناف والأسعار والكميات", color = Muted, fontSize = 12.sp)
        Spacer(Modifier.height(14.dp))
        if (products.isEmpty()) {
            Surface(color = Color.White, shape = RoundedCornerShape(20.dp), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(28.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Default.Inventory2, null, tint = Green, modifier = Modifier.size(42.dp))
                    Spacer(Modifier.height(10.dp))
                    Text("لا توجد منتجات بعد", fontWeight = FontWeight.Bold, color = Ink)
                    Text("اضغط زر + لإضافة أول منتج", color = Muted, fontSize = 12.sp)
                }
            }
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(9.dp), contentPadding = PaddingValues(bottom = 90.dp)) {
                items(products, key = { it.id }) { product ->
                    Surface(color = Color.White, shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth()) {
                        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                            Surface(color = Color(0xFFE5F6EF), shape = RoundedCornerShape(12.dp), modifier = Modifier.size(42.dp)) {
                                Box(contentAlignment = Alignment.Center) { Icon(Icons.Default.Inventory2, null, tint = Green) }
                            }
                            Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) {
                                Text(product.name, color = Ink, fontWeight = FontWeight.SemiBold)
                                Text("الكمية: ${product.quantity}  •  ${product.barcode.ifBlank { "بدون باركود" }}", color = Muted, fontSize = 11.sp)
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text("₪ ${"%.2f".format(product.priceAgorot / 100.0)}", color = Green, fontWeight = FontWeight.Bold)
                                TextButton(onClick = { onDelete(product.id) }, contentPadding = PaddingValues(0.dp)) { Text("حذف", color = Color(0xFFDC5555), fontSize = 11.sp) }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun AddProductDialog(onDismiss: () -> Unit, onSave: (String, String, String, String) -> Unit) {
    var name by remember { mutableStateOf("") }
    var barcode by remember { mutableStateOf("") }
    var price by remember { mutableStateOf("") }
    var qty by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("إضافة منتج جديد", fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(name, { name = it }, label = { Text("اسم المنتج") }, singleLine = true)
                OutlinedTextField(barcode, { barcode = it }, label = { Text("الباركود (اختياري)") }, singleLine = true)
                OutlinedTextField(price, { price = it }, label = { Text("سعر البيع بالشيكل") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), singleLine = true)
                OutlinedTextField(qty, { qty = it }, label = { Text("الكمية") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), singleLine = true)
            }
        },
        confirmButton = { TextButton(onClick = { if (name.isNotBlank() && (price.toDoubleOrNull() ?: -1.0) >= 0) onSave(name, barcode, price, qty) }) { Text("حفظ") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } }
    )
}

@Composable
fun PlaceholderScreen(modifier: Modifier, title: String, description: String) {
    Column(modifier.fillMaxSize().padding(20.dp)) {
        Text(title, color = Ink, fontSize = 23.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        Text(description, color = Muted, fontSize = 13.sp)
        Spacer(Modifier.height(20.dp))
        Surface(color = Color.White, shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth()) {
            Text("هذا القسم ضمن خطة التطوير القادمة.", Modifier.padding(20.dp), color = Muted)
        }
    }
}
