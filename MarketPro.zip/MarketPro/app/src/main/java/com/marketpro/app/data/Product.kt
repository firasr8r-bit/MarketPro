package com.marketpro.app.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "products")
data class Product(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val barcode: String = "",
    val priceAgorot: Long,
    val quantity: Double,
    val updatedAt: Long = System.currentTimeMillis(),
    val syncPending: Boolean = true
)
